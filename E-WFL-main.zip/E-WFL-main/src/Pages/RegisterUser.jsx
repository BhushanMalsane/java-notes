import React from 'react'

const RegisterUser = () => {
  return (
    <div>RegisterUser</div>
  )
}

export default RegisterUser