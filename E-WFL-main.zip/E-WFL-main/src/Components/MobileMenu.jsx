import React from 'react'

const MobileMenu = () => {
  return (
    <div>MobileMenu</div>
  )
}

export default MobileMenu